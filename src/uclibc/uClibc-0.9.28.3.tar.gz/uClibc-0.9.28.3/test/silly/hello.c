#include<stdio.h>
#include <stdlib.h>

int main(void)
{
    printf("hello world\n");
    exit(42);
}
