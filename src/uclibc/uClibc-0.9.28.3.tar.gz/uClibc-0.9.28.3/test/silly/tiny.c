#include <unistd.h>

int main(void)
{
    _exit(42);
}
