#include <math.h>
#include <stdlib.h>
#include <stdio.h>

int main(void) {
    double d1, d2;
    d1 = 0.6;  d2 = rint(d1);
    printf("d1 = %f, d2 = %f\n", d1, d2);
    return 0;                            
}

