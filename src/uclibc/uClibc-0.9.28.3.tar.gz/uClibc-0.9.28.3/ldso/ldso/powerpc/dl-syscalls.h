/* We can't use the real errno in ldso, since it has not yet
 * been dynamicly linked in yet. */
#define __UCLIBC_MMAP_HAS_6_ARGS__

#include "sys/syscall.h"
extern int _dl_errno;
#undef __set_errno
#define __set_errno(X) {(_dl_errno) = (X);}
